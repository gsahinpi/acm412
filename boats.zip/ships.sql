-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 08 May 2018, 09:30:46
-- Sunucu sürümü: 10.1.31-MariaDB
-- PHP Sürümü: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ships`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yachts`
--

CREATE TABLE `yachts` (
  `id` int(11) NOT NULL,
  `itemNum` text NOT NULL,
  `description` text NOT NULL,
  `imageURL` text NOT NULL,
  `cost` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Tablo döküm verisi `yachts`
--

INSERT INTO `yachts` (`id`, `itemNum`, `description`, `imageURL`, `cost`) VALUES
(1, 'BM1', 'Base model yacht. Features sauna, two kitchens,\r\n	 \"and four-car garage. <B>Perfect entry-level \" \r\n	 \"yacht for the first-time buyer</B>\r\n	 \r\n	', 'images/yacht.jpg', 72678922.99),
(2, 'MR1', 'Mid-range yacht. Features helipad, bowling alley,and 15 bedrooms. <B>Trade up from a BM1 today!</B>.', 'images/yacht.jpg\r\n	 ', 145357845.98),
(3, 'HE1', 'High-end yacht. Features onboard 18-hole golf course, onboard polo grounds, and ski jump. <B>Bonus: for a limited time only, a mid-sized tropical island country will be included at no extra cost.</B>\r\n	 ', 'images/yacht.jpg\r\n	 ', 7267892299),
(4, 'Valdez\r\n	', 'Slightly damaged former Alaskan touring boat. <B>Special price won\'t last long!</B>\r\n	 ', 'images/tanker.jpg\r\n	 ', 9.95),
(5, 'BigBertha', 'Tired of cramped quarters on your boat? \r\nThis roomy model has plenty of space to stretch \r\n	 your legs. <B>10 million gallon onboard \r\n	 swimming pool included!</B>,\r\n	', 'images/tanker.jpg\r\n	', 20000000),
(6, 'EcoDisaster', 'OK, ok, so this model is not exactly politically correct. <B>But you\'re not one to pass up a bargain just because of a few <S>Greenpeace</S> pesky demonstratorsare you?</B>.\r\n			 ', 'images/tanker.jpg\r\n			 ', 100000000),
(7, 'SafeT-1A', 'A safe and secure boat, perfect for vacations. <B>Note:</B> no crew provided. If crew is desired, please see model SafeT-1B.', 'images/carrier.jpg', 3167492481.99);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `yachts`
--
ALTER TABLE `yachts`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `yachts`
--
ALTER TABLE `yachts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
