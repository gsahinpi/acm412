package boats;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.mysql.jdbc.PreparedStatement;


public class connector {
	
	Connection  con=null;
	String  url="jdbc:mysql://127.0.0.1/ships";	
	public connector()
	{
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(url, "myblog", "1234");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}//cons
	
	SimpleItem getItem(String itemnum)
	{
		SimpleItem c=null;
	String selectSQL = "SELECT * FROM yachts WHERE itemNum ='"+itemnum+"'";
	java.sql.PreparedStatement preparedStatement;
	ResultSet rs=null;
	Statement smt=null;
	try {
		smt=con.createStatement();
		rs=smt.executeQuery(selectSQL);
		
		while (rs.next()) {
			
			c=new SimpleItem();
			c.setDescription(rs.getString("description"));
			c.setItemNum( rs.getString("itemNum"));
			c.setCost(rs.getDouble("cost"));
			c.setImageURL(rs.getString("imageURL"));
			return c;
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return c;
		
	}
	ArrayList <SimpleItem> gettitles()
	{
		ArrayList <SimpleItem>  returnlist;
		returnlist = new ArrayList<SimpleItem>();
		ResultSet rs=null;
		Statement smt=null;
		
		
		try {
			smt=con.createStatement();
			rs=smt.executeQuery("Select * from yachts");
			while (rs.next())
			{
		SimpleItem c= new SimpleItem();
		c.setDescription(rs.getString("description"));
		c.setItemNum(rs.getString("itemNum"));
		
		
		returnlist.add(c);
		
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return returnlist;
	}

	public void inseritem(String topic,String comment)
	{
		String tableName = "first";
		String template ="INSERT INTO first (topic,content) VALUES (?, ?)";
		
		
		 try {
			java.sql.PreparedStatement inserter = 
				        con.prepareStatement(template);
			
			inserter.setString(1, topic);
	        inserter.setString(2, comment);
	        inserter.executeUpdate();
	        
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		connector mydb=new connector();
	//	mydb.inseritem("696", "Execute order 66");
		SimpleItem d=mydb.getItem("BM1");
		ArrayList<SimpleItem> dummy=mydb.gettitles();
		for (SimpleItem c: dummy)
		{
			System.out.println(c.getDescription());
			
		}

	}

}
