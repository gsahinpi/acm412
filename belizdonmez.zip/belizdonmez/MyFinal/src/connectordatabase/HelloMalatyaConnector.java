package connectordatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class HelloMalatyaConnector {
	ArrayList<datamodel> dataContainer;
	private Connection connect = null;
    private Statement statement = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    
public HelloMalatyaConnector() {
		
		dataContainer=new ArrayList<datamodel>();
		try{
		Class.forName("com.mysql.jdbc.Driver");
        // Setup the connection with the DB
        connect = DriverManager
                        .getConnection("jdbc:mysql://localhost/hellomalatya?"
                                        + "user=bello&password=1234");
		}catch(ClassNotFoundException | SQLException e){
			e.printStackTrace();
		}
		
	}
	public void insertItem(String firstname, String lastname, String house, String status)
	{
		 PreparedStatement preparedStatement = null;
		  try {
			preparedStatement = connect
			          .prepareStatement("insert into hellomalatya values (default, ?, ?, ?, ?)");
			
			preparedStatement.setString(1, firstname);
			 preparedStatement.setString(2, lastname);
			 preparedStatement.setString(3, house);
			 preparedStatement.setString(4, status);
			 preparedStatement.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}//insertitem
	public ArrayList<datamodel> getitems()
	{
		ArrayList<datamodel>dummy=new ArrayList<datamodel>();
		
		PreparedStatement preparedStatement2;
		try {
			preparedStatement2 = connect
			          .prepareStatement("select * from hellomalatya");
			ResultSet results=preparedStatement2.executeQuery();
			while(results.next())
			{
				datamodel d=new datamodel();
				d.setFirstname(results.getString("firstname"));
				d.setLastname(results.getString("lastname"));
				d.setHouse(results.getString("house"));
				d.setStatus(results.getString("status"));
				dummy.add(d);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dummy; 
		
		
	}
	public void insertvals(String firstname, String lastname, String house, String status) {
		// TODO Auto-generated method stub
		
	}
	public void getallthedata() {
		// TODO Auto-generated method stub
		
	}
}

