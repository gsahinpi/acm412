package connectordatabase;

import java.util.ArrayList;



public class HelloMalatyaDriver {
	public static void main(String[] args)	{
		HelloMalatyaConnector o=new HelloMalatyaConnector();
		o.insertItem("beliz","donmez", "village", "student");
		ArrayList<datamodel>d=o.getitems();
		for(datamodel d2:d)
		{
			System.out.println(d2.firstname);
			System.out.println("......");
			System.out.println(d2.getLastname());
			System.out.println(".....");
			System.out.println(d2.getHouse());
			System.out.println(".....");
			System.out.println(d2.getStatus());
			System.out.println(".....");
		}
	}
}
