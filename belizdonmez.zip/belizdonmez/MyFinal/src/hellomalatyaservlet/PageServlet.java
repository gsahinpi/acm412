package hellomalatyaservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connectordatabase.HelloMalatyaConnector;
import connectordatabase.datamodel;







/**
 * Servlet implementation class PageServlet
 */
@WebServlet("/PageServlet")
public class PageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        HelloMalatyaConnector cnt=new HelloMalatyaConnector();
		String isclicked=request.getParameter("dgm");
		
	//System.out.println(isclicked+ " "+ isclicked2);
		String page="<html> <body>";
		if (isclicked!=null )
		{
			
			//page+="<script > alert(\"aa\")</script>";
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
	    String house=request.getParameter("house");
	    String status=request.getParameter("status");
	 cnt.insertvals(firstname, lastname, house, status);
		
			
		}
		cnt.getallthedata();
		ArrayList<datamodel> pointer=cnt.getitems();
		page+="<table border='1'>";
		page+="<tr><th>First Name</th><th>Last Name</th><th>House</th><th>Status</th></tr>";
		for (datamodel m:pointer)
		{
				
			page+="<tr>"+
		                "<td>"+m.getFirstname()+"</td>"+
		                "<td>"+m.getLastname()+"</td>"+
		                "<td>"+m.getHouse()+"</td>"+
		                "<td>"+m.getStatus()+"</td>"+
		               
		                "</tr>";
		}
		
		
		
		PrintWriter out=response.getWriter();
		out.println(page);
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
