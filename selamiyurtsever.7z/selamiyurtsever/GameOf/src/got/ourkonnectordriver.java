package got;

import java.util.ArrayList;

public class ourkonnectordriver {
	public static void main(String[] args)	{
	ourkonnektor o=new ourkonnektor();
	o.insertItem("rengar","hunter", "lol"," dead");
	ArrayList<datamodel>d=o.getitems();
	for(datamodel d2:d)
	{
		System.out.println(d2.FirstName);
		System.out.println("!!!!!!!");
		System.out.println(d2.LastName);
		System.out.println("----");
		System.out.println(d2.House);
		System.out.println("!!!!!!!");
		System.out.println(d2.Status);
		System.out.println("!!!!!!!");
		
	}
}
	}
