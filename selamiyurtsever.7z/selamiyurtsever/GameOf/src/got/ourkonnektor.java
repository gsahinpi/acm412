package got;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import got.datamodel;
                                           
public class ourkonnektor {

	ArrayList<datamodel> dataContainer;
	private Connection connect = null;
    private Statement statement = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;


	public ourkonnektor() {
		
		dataContainer=new ArrayList<datamodel>();
		try{
		Class.forName("com.mysql.jdbc.Driver");
        // Setup the connection with the DB
        connect = DriverManager
                        .getConnection("jdbc:mysql://localhost/got?"
                                        + "user=selami&password=1234");
		}catch(ClassNotFoundException | SQLException e){
			e.printStackTrace();
		}
		
	}


public void insertItem(String FirstName, String LastName, String House, String Status)
{
	 PreparedStatement preparedStatement = null;
	  try {
		preparedStatement = connect
		          .prepareStatement("insert into got values (default, ?, ?, ?)");
		 preparedStatement.setString(1, FirstName);
		 preparedStatement.setString(2, LastName);
		 preparedStatement.setString(3, House);
		 preparedStatement.setString(4, Status);
		 preparedStatement.executeUpdate();

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}//insertitem
public ArrayList<datamodel> getitems()
{
	ArrayList<datamodel>dummy=new ArrayList<datamodel>();
	PreparedStatement preparedStatement2;
	try {
		preparedStatement2 = connect
		          .prepareStatement("select * from got.got");
		ResultSet results=preparedStatement2.executeQuery();
		while(results.next())
		{
			datamodel d=new datamodel();
			d.setFirstName(results.getString("FirstName"));
			d.setLastName(results.getString("LastName"));
			d.setHouse(results.getString("House"));
			d.setStatus(results.getString("Status"));
			dummy.add(d);
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return dummy;
	
	
}

}
