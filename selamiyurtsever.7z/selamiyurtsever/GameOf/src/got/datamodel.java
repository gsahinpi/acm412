package got;

public class datamodel {
	int id;
	String FirstName;
	String LastName;
	String House;
	String Status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
	}
	public String LastName() {
		return LastName;
	}
	public void setLastName(String LastName) {
		this.LastName = LastName;
	}
	
	public String House() {
		return House;
	}
	public void setHouse(String House) {
		this.House = House;
	}
	
	public String Status() {
		return Status;
	}
	public void setStatus(String Status) {
		this.Status = Status;
	}


}
