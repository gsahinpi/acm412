package pages;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import got.ourkonnektor;
import got.datamodel;
import got.ourkonnectordriver;

/**
 * Servlet implementation class page
 */
@WebServlet("/page")
public class page extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public page() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ourkonnektor o = new ourkonnektor();

		ArrayList<datamodel> mydata = o.getitems();
		PrintWriter out= response.getWriter();
		String context="<html>  <body>";

		for(datamodel d:mydata)
		{
			context="<li>" + d.getFirstName()+"</li>";
			context+="<li>" + d.LastName()+"</li>";
			context+="<li>" + d.House()+"</li>";
			context+="<li>" + d.Status()+"</li>";
		}
		context+="</ul\">";
		context = "<html> <body>";
		context+="</body> </html>";
			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
